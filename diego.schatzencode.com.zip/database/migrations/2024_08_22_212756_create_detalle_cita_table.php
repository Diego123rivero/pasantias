<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('detalle_cita', function (Blueprint $table) {
            $table->id(); // ID autoincremental para la tabla detalle_cita

            // Clave foránea hacia la tabla terreno
            $table->unsignedBigInteger('id_terreno');
            $table->foreign('id_terreno')->references('id')->on('terreno')->onDelete('cascade');

            // Clave foránea hacia la tabla sucursal
            $table->unsignedBigInteger('id_sucursal')->nullable();
            $table->foreign('id_sucursal')->references('id')->on('sucursal')->onDelete('cascade');

            // Clave foránea hacia la tabla sucursal
            $table->unsignedBigInteger('id_fecha')->nullable();
            $table->foreign('id_fecha')->references('id')->on('fecha')->onDelete('cascade');

            // Clave foránea hacia la tabla cita
            $table->unsignedBigInteger('id_cita');
            $table->foreign('id_cita')->references('id')->on('cita')->onDelete('cascade');

            $table->timestamps(); // Campos de timestamps (created_at, updated_at)
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('detalle_cita');
    }
};
