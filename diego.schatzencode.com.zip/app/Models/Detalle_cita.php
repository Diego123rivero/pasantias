<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Detalle_cita extends Model
{
    use HasFactory;
    
    protected $table = "detalle_cita";
    protected $primaryKey = "id";
    protected $fillable = ['id_terreno', 'id_cita','id_sucursal','id_fecha'];
    protected $hidden = ['id'];

    // Relación con Terreno
    public function terreno()
    {
        return $this->belongsTo(Terreno::class, 'id_terreno', 'id');
    }

    public function sucursal()
    {
        return $this->belongsTo(Sucursal::class, 'id_sucursal', 'id');
    }

    public function fecha()
    {
        return $this->belongsTo(Fecha::class, 'id_fecha', 'id');
    }
}


    

