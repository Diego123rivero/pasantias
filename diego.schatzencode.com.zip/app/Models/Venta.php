<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Venta extends Model
{
    use HasFactory;
    protected $table="venta";
    protected $primarykey="id";
    protected $fillable=['fecha_vendida','terreno_vendido','sucursal_id'];
    protected $hidden=['id'];
    public function sucursal(){
        return $this->belongsTo(Sucursal::class);
    }
}