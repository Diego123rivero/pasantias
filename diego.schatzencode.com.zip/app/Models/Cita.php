<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cita extends Model
{
    use HasFactory;
    protected $table="cita";
    protected $primaryKey="id";
    protected $fillable=['usuario_id'];
    protected $hidden=['id'];
    
    public function usuario()
    {
        return $this->belongsTo(Usuario::class, 'usuario_id'); // Asegúrate de usar el nombre correcto de la columna
    }
    public function detalles()
    {
        return $this->hasMany(Detalle_cita::class, 'id_cita', 'id');
    }
}