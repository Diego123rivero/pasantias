<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Usuario extends Model
{
    use HasFactory;
    protected $table="usuario";
    protected $primaryKey="id";
    protected $fillable=['usuarios','gmail','contraseña'];
    protected $hidden=['id'];
    public function fecha(){
        return $this->belongsTo(Fecha::class,'id');
    }
    public function cita()
    {
        return $this->belongsToMany(Cita::class,'id');
    }
}