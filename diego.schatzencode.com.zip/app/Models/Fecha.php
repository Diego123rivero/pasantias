<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Fecha extends Model
{
    use HasFactory;
    protected $table="fecha";
    protected $primarykey="id";
    protected $fillable=['fechas_disp','horarios_de_atencion','usuario_id','id_cita'];
    protected $hidden=['id'];
    public function cita(){
        return $this->hasMany(Cita::class,'id');
    }
    public function sucursal(){
        return $this->hasMany(Sucursal::class,'id');
    }
    public function usuario(){
        return $this->belongsTo(Usuario::class,'usuario_id','id');
    }
}