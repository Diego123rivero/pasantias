<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Sucursal extends Model
{
    use HasFactory;
    protected $table="sucursal";
    protected $primarykey="id";
    protected $fillable=['encargado','nombre','fecha_id','id_cita'];
    protected $hidden=['id'];
    public function venta(){
        return $this->hasMany(Venta::class,'id');
    }
    public function fecha(){
        return $this->belongsTo(Fecha::class,'fecha_id','id');
    }
}