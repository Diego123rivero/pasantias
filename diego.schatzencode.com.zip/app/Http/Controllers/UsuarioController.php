<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Usuario;

class UsuarioController extends Controller
{
    public function index()
    {
        $us = Usuario::all();
        return view('usuario', ['us' => $us]);
    }

    public function show($id)
    {
        $usuario = Usuario::findOrFail($id);
        return view('usuario_ver', ['usuario' => $usuario]);
    }

    public function destroy($id)
    {
        $usuario = Usuario::findOrFail($id);
        $usuario->delete();
        $us = Usuario::all();
        return view('usuario', ['us' => $us]);
    }

    public function create()
    {
        return view('usuario_crear');
    }

    public function edit(string $id)
    {
        $usuario = Usuario::findOrFail($id);
        return view('usuario_editar', ['usuario' => $usuario]);
    }

    public function update(Request $request, string $id)
    {
        $usuario = Usuario::findOrFail($id);
        $usuario->usuarios = $request->usuario;
        $usuario->gmail = $request->gmail;
        $usuario->contraseña = $request->contraseña;
        $usuario->save();

        $usuarios = Usuario::all();
        return view('usuario', ['us' => $usuarios]);
    }

    public function store(Request $request)
    {
        $usuario = new Usuario($request->all());
        $usuario->save();

        $us = Usuario::all();
        return view('welcome',['us'=>$us]);
    }
}