<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Sucursal;
use App\Models\Fecha;
class SucursalController extends Controller
{
    public function index(){
        $su = Sucursal::with('fecha')->get();
        return view('sucursal', ['su' => $su]);
        //dd($variable);
        //return view('curso',['silla'=>$silla]);
    }

    public function store(Request $request)
    {
        $sucursal=new Sucursal($request->all());
        $sucursal->save();
        $su = Sucursal::all();
        //dd($variable);

        return view('sucursal',['su'=>$su]);
       
      
    }
    public function create(){
        $fecha=Fecha::all();
        return view('sucursal_crear',['fecha'=>$fecha]);
    }
    public function show($id)
    {
        $sucursal=Sucursal::findOrFail($id);
        return view('sucursal_ver',['su'=>$sucursal]);
      
    }
    public function edit(string $id)
    {
        $fecha = Fecha::all();
        $sucursal= Sucursal::findOrfail($id);
        return view('sucursal_editar',['sucursal'=>$sucursal, 'fecha'=>$fecha]);

    }
    


    public function update(request $request, $id)
    {
        $sucursal=Sucursal::findOrFail($id);
        $sucursal->encargado=$request->encargado;
        $sucursal->nombre=$request->nombre;
        $sucursal->fecha_id = $request->fecha_id;
        $sucursal->save();

        $su=Sucursal::all();
        return view('sucursal',['su'=>$su]);
    }

    public function destroy($id)
    {
        $sucursal=Sucursal::findOrFail($id);
        $sucursal->delete();
        $su = Sucursal::all();
        //dd($variable);
        return view('sucursal',['su'=>$su]);
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    
     
   
}
