<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Rol;
class RolController extends Controller
{
    public function index()
    {
        $ro = rol::all();
        //dd($variable);
        return view('rol',['ro'=>$ro]);
    }

    public function store(Request $request)
    {
        $rol=new Rol($request->all());
        $rol->save();
        $ro = Rol::all();
        //dd($variable);

        return view('rol',['ro'=>$ro]);
       
      
    }
    public function create()
    {
        return view('rol_crear');
    }
    public function show($id)
    {
        $rol=Rol::findOrFail($id);
        return view('rol_ver',['ro'=>$rol]);
      
    }
    public function edit($id)
    {
        $rol = Rol::findOrFail($id);
        /**/
        return view('rol_editar',['rol'=>$rol]);
   
    }
    


    public function update(request $request, $id)
    {
        $rol=Rol::findOrFail($id);
        $rol->nombre=$request->nombre;
        $rol->save();

        $ro=rol::all();
        return view('rol',['ro'=>$ro]);
    }




    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    
     
    public function destroy($id)
    {
        $rol=Rol::findOrFail($id);
        $rol->delete();
        $ro = Rol::all();
        //dd($variable);
        return view('rol',['ro'=>$ro]);
    }
}


