<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Comentario;
class ComentarioController extends Controller
{
    public function index()
    {
        $co = Comentario::all();
        //dd($co);
        return view('comentario',['co'=>$co]);
    }

    public function store(Request $request)
    {
        $comentario=new Comentario($request->all());
        $comentario->save();
        $co = Comentario::all();
        //dd($variable);

        return view('welcome',['co'=>$co]);
       
      
    }
    
    public function create()
    {
        return view('comentario_crear');
    }
    public function show($id)
    {
        $comentario=Comentario::findOrFail($id);
        return view('comentario_ver',['comentario'=>$comentario]);
      
    }
    public function edit($id)
    {
        $comentario = Comentario::findOrFail($id);
        /**/
        return view('comentario_editar',['comentario'=>$comentario]);
   
    }
    


   



    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    
     
    public function destroy($id)
    {
        $comentario=Comentario::findOrFail($id);
        $comentario->delete();
        $co = Comentario::all();
        //dd($variable);
        return view('comentario',['co'=>$co]);
    }
}