<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Fecha;
use App\Models\Usuario;
class FechaController extends Controller
{
    public function index(){
        $fe = Fecha::with('usuario')->get();
        return view('fecha', ['fe' => $fe]);
        //dd($variable);
        //return view('curso',['silla'=>$silla]);
    }

    public function store(Request $request)
    {
        $fecha=new Fecha($request->all());
        $fecha->save();
        $fe = Fecha::all();
        //dd($variable);

        return view('fecha',['fe'=>$fe]);
       
      
    }
    public function create(){
        $usuario=Usuario::all();
        return view('fecha_crear',['usuario'=>$usuario]);
    }
    public function show($id){
        $fecha = Fecha::findOrFail($id);
        return view('fecha_ver', ['fecha'=>$fecha]);
    }
    public function destroy($id){
        $fecha = Fecha::findOrFail($id);
        $fecha->delete();
        $fe = Fecha::all();
        return view('fecha',['fe'=>$fe]);
    }
    public function edit($id)
    {
        $usuario = Usuario::all();
        $fecha= Fecha::findOrfail($id);
        return view('fecha_editar',['fecha'=>$fecha, 'usuario'=>$usuario]);

   
    }
    public function update(request $request, $id)
    {
        $fecha= Fecha::findOrFail($id);
        $fecha->fechas_disp=$request->fechas_disp;
        $fecha->horarios_de_atencion=$request->horarios_de_atencion;
        $fecha->usuario_id = $request->usuario_id;
        $fecha->save();

        $fe=Fecha::all();
        return view('fecha',['fe'=>$fe]);
    }
    


    /*public function update(request $request, $id)
    {
        $sucursal=Sucursal::findOrFail($id);
        $sucursal->encargado=$request->encargado;
        $sucursal->nombre=$request->nombre;
        $sucursal->horarios_de_atencion=$request->horarios_de_atencion;
        $sucursal->save();

        $su=Sucursal::all();
        return view('sucursal',['su'=>$su]);
    }

*/


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    
     

}