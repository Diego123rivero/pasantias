<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Venta;
use App\Models\Sucursal;
use Illuminate\Support\Facades\DB;
class VentaController extends Controller
{
    public function index(){
        $ve = Venta::with('sucursal')->get();
        return view('venta', ['ve' => $ve]);
    }

    public function store(Request $request)
    {
        $venta=new Venta($request->all());
        $venta->save();
        $ve = Venta::all();
        //dd($variable);

        return view('venta',['ve'=>$ve]);
       
      
    }
    public function show($id)
    {
        $venta=Venta::findOrFail($id);
        return view('venta_ver',['venta'=>$venta]);
      
    }
    public function create(){
        $sucursal=Sucursal::all();
        return view('venta_crear',['sucursal'=>$sucursal]);
    }

    public function edit($id)
    {
        $sucursal = Sucursal::all();
        $venta = Venta::findOrFail($id);
        /**/
        return view('venta_editar',['venta'=>$venta],['sucursal'=>$sucursal]);
   
    }

    public function update(request $request, $id)
    {
        $venta=Venta::findOrFail($id);
        $venta->fecha_vendida = $request->fecha_vendida;
        $venta->terreno_vendido = $request->terreno_vendido;
        $venta->sucursal_id=$request->sucursal_id;
        $venta->save();

        $ve=Venta::all();
        return view('venta',['ve'=>$ve]);
    }

    public function destroy($id)
    {
        $venta=Venta::findOrFail($id);
        $venta->delete();
        $ve = Venta::all();
        //dd($variable);
        return view('venta',['ve'=>$ve]);
    }
}