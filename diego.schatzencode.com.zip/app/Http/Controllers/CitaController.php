<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Cita;
use App\Models\Sucursal;
use App\Models\Detalle_cita;
use App\Models\Fecha;
use App\Models\Terreno;
use App\Models\Usuario;

class CitaController extends Controller
{
    public function index()
    {
        // Cargar citas junto con detalles y las relaciones de terrenos, sucursales y fechas
        $ci = Cita::with(['detalles.terreno', 'detalles.sucursal', 'detalles.fecha', 'usuario'])->get();
        $usuarios = Usuario::all();

        return view('cita', ['ci' => $ci, 'usuarios' => $usuarios]);
    }

    public function show($id)
    {
        {
            // Encuentra la cita con las relaciones
            $cita = Cita::with(['detalles.terreno', 'detalles.sucursal', 'detalles.fecha', 'usuario'])->findOrFail($id);
            
            // Pasar la variable 'cita' a la vista
            return view('cita_ver', ['cita' => $cita]);
        }
    }
    

    public function destroy($id)
    {
        $cita = Cita::findOrFail($id);
        $cita->delete();
        $ci = Cita::all();
        return view('cita', ['ci' => $ci]);
    }

    public function create()
    {
        $fecha = Fecha::all();
        $sucursal = Sucursal::all();
        $terreno = Terreno::all();
        $usuario = Usuario::all();

        return view('cita_crear', [
            'sucursal' => $sucursal,
            'fecha' => $fecha,
            'terreno' => $terreno,
            'usuario' => $usuario
        ]);
    }

    public function store(Request $request)
    {
        // Validar los datos recibidos
        $validatedData = $request->validate([
            'id_terreno' => 'required|array',
            'id_terreno.*' => 'exists:terreno,id',
            'id_sucursal' => 'required|array',
            'id_sucursal.*' => 'exists:sucursal,id',
            'id_fecha' => 'required|array',
            'id_fecha.*' => 'exists:fecha,id',
            'usuario_id' => 'required|exists:usuario,id',
            'password' => 'required|string',
        ]);
    
        // Llamar al método para verificar la contraseña
        $response = $this->verificarContraseña($request->usuario_id, $request->password);
    
        if ($response['success']) {
            // Proceder a guardar la cita
            DB::transaction(function () use ($request) {
                $cita = new Cita;
                $cita->usuario_id = $request->usuario_id; // Guarda el usuario
                $cita->save();
    
                // Obtener IDs del request
                $id_terreno = $request->get('id_terreno');
                $id_sucursal = $request->get('id_sucursal');
                $id_fecha = $request->get('id_fecha');
    
                foreach ($id_terreno as $index => $terreno_id) {
                    if (isset($id_sucursal[$index]) && isset($id_fecha[$index])) {
                        $detalle = new Detalle_cita;
                        $detalle->id_cita = $cita->id;
                        $detalle->id_terreno = $terreno_id;
                        $detalle->id_sucursal = $id_sucursal[$index];
                        $detalle->id_fecha = $id_fecha[$index];
    
                        $detalle->save();
                    }
                }
            });
    
            // Redirigir a la página de la tabla de citas con un mensaje de éxito
            return redirect()->route('inicio.ir')->with('success', 'Cita creada con éxito');
        } else {
            // Si la contraseña es incorrecta, redirigir de nuevo con un mensaje de error
            return redirect()->back()->withErrors(['password' => 'La contraseña es incorrecta.'])->withInput();
        }
    }
        

    public function edit($id)
    {
        $sucursal = Sucursal::all();
        $fecha = Fecha::all();
        $terreno = Terreno::all();
        $cita = Cita::findOrFail($id);

        return view('cita_editar', [
            'ci' => $cita,
            'fecha' => $fecha,
            'terreno' => $terreno,
            'sucursal' => $sucursal
        ]);
    }

    public function update(Request $request, $id)
    {
        $cita = Cita::findOrFail($id);
        $cita->fecha_id = $request->fecha_id;
        $cita->sucursal_id = $request->sucursal_id;
        $cita->save();

        $citas = Cita::all();
        return view('cita', ['ci' => $citas]);
    }

    // Método para verificar la contraseña
    public function verificarContraseña($usuarioId, $password)
    {
        $usuario = Usuario::findOrFail($usuarioId);
        if ($password === $usuario->contraseña) {
            return ['success' => true];
        }

        return ['success' => false];
    }
}
