<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Terreno;
class TerrenoController extends Controller
{
    public function index()
    {
        $te = Terreno::all();
        //dd($variable);
        return view('terreno',['te'=>$te]);
    }

    public function store(Request $request)
    {
        $terreno=new Terreno($request->all());
        $terreno->save();
        $te = Terreno::all();
        //dd($variable);

        return view('terreno',['te'=>$te]);
    }


    public function create()
    {
        return view('terreno_crear');
    }

    
    public function show($id)
    {
        $terreno=Terreno::findOrFail($id);
        return view('terreno_ver',['te'=>$terreno]);
      
    }

    public function edit($id)
    {
        $terreno = Terreno::findOrFail($id);
        /**/
        return view('terreno_editar',['te'=>$terreno]);
   
    }
    public function update(request $request, $id)
    {
        $terreno= Terreno::findOrFail($id);
        $terreno->codigo=$request->codigo;
        $terreno->save();

        $terre=Terreno::all();
        return view('terreno',['te'=>$terre]);
    }
    public function destroy($id){
        $terreno = Terreno::findOrFail($id);
        $terreno->delete();
        $terre = Terreno::all();
        return view('terreno',['te'=>$terre]);
    }
   
}
