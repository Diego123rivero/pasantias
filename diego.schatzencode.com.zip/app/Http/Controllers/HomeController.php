<?php

namespace App\Http\Controllers;

use App\Models\Sucursal;
use App\Models\Usuario;
use App\Models\Insumos_produccion;



class HomeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $nombreSucursal = $this->graficoSucursal();
        $nombreUsuario = $this->graficoUsuario();
     

        return view('admin.home', compact('nombreSucursal','nombreUsuario'));
    }

    public function graficoSucursal()
    {
        $sucursal = Sucursal::all();
   
        $nombreSucursal = $sucursal->groupBy('nombre')->map(function ($item) {
           return $item->count();
        });

        return $nombreSucursal;
    }
    public function graficoUsuario()
    {
        $usuario = Usuario::all();
   
        $nombreUsuario = $usuario->groupBy('usuarios')->map(function ($item) {
           return $item->count();
        });

        return $nombreUsuario;
    }

}